
window.onload = function () {
console.log('grrrriiiiid');
let grid = document.getElementById("grid-preview");
let imgs=grid.children;
 imgs.forEach(element => {
    console.log(element);
 });

};